# YouTube Trending Video Analytics (Starter Project)

**Objective:** Uncover patterns in trending videos by analyzing YouTube datasets across regions.

**Tools:** Python (Pandas, Matplotlib), SQL (SQLite), Tableau

---

## Quickstart

1. Install Python 3.10+ with `pandas`, `matplotlib`.
2. Run the pipeline:
   ```bash
   python scripts/01_clean_and_standardize.py
   python scripts/02_sentiment_analysis.py
   python scripts/03_sql_load_and_rank.py
   python scripts/04_time_series_and_duration.py
   ```

Outputs are written to `data/outputs/` (CSV, SQLite DB) and `figures/` (PNGs).

---

## SQL: Rank Categories by Avg Views

```sql
SELECT region, category, AVG(views) AS avg_views
FROM trending
GROUP BY region, category
ORDER BY region ASC, avg_views DESC;
```

---

## Tableau

Use these as data sources:
- `data/outputs/sentiment_scored.csv`
- `data/outputs/category_avg_views_by_region.csv`
- `data/outputs/top_like_rate_by_region.csv`

**Suggested Dashboards:**
- **Most Popular Genres & Sentiments** – bar chart for avg views by category, stacked sentiment share, KPI tiles.
- **Region-wise Comparison** – side-by-side bars for category popularity per region, line chart of daily total views per region.

---

## Notes on Sentiment
This starter uses a simple lexicon. For production, replace with VADER or a transformer model.

---

## Folder Layout
```
youtube_trending_analytics/
├─ data/
│  ├─ raw/
│  ├─ clean/
│  └─ outputs/
├─ figures/
├─ scripts/
├─ sql/
├─ tableau/
└─ reports/
```
