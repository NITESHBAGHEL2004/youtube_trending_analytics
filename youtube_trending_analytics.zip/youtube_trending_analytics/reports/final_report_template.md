# Final Report – YouTube Trending Video Analytics

**Date:** 2025-08-20

## Executive Summary
- Summarize top findings (popular categories by region, sentiment skew).

## Data & Methods
- Cleaning, simple lexicon sentiment, SQLite aggregations, Matplotlib charts, Tableau dashboards.

## Key Insights
1. Most popular genres (by avg views).
2. Sentiment distribution by region.
3. Trending duration by category.
4. Top like-rate videos per region.

## Region-wise Comparison
- Highlight 2–3 differences across regions.

## Storytelling
- Tie spikes to publish dates/updates or events.

## Limitations & Next Steps
- Use real YouTube trending CSVs.
- Upgrade sentiment model.
- Add richer time-series analysis.
