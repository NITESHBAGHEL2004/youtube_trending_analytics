import pandas as pd

INPUT = "/mnt/data/youtube_trending_analytics/data/raw/youtube_trending_sample.csv"
OUTPUT = "/mnt/data/youtube_trending_analytics/data/clean/youtube_trending_clean.csv"

def main():
    df = pd.read_csv(INPUT)
    expected = ["video_id","title","tags","category","publish_time","trending_date","trending_days","views","likes","comments","region"]
    for c in expected:
        if c not in df.columns:
            df[c] = None
    df["publish_time"] = pd.to_datetime(df["publish_time"], errors="coerce", utc=True)
    df["trending_date"] = pd.to_datetime(df["trending_date"], errors="coerce").dt.date
    for c in ["trending_days","views","likes","comments"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df["title"] = df["title"].fillna("").str.strip()
    df["tags"] = df["tags"].fillna("").str.lower()
    df["category"] = df["category"].fillna("Unknown").str.strip()
    df["region"] = df["region"].fillna("Unknown").str.upper()
    df = df.drop_duplicates(subset=["video_id","trending_date","region"])
    df = df.dropna(subset=["video_id","title","trending_date","views"])
    df.to_csv(OUTPUT, index=False)
    print("Cleaned file written to:", OUTPUT)

if __name__ == "__main__":
    main()
