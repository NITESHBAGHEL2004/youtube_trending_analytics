import re, pandas as pd

INPUT = "/mnt/data/youtube_trending_analytics/data/clean/youtube_trending_clean.csv"
OUTPUT = "/mnt/data/youtube_trending_analytics/data/outputs/sentiment_scored.csv"

POSITIVE = set(['amazing','great','awesome','love','fantastic','best','cool','wow','good','like','beautiful','win','happy','🔥','💯','✨','🎉','😍','👍'])
NEGATIVE = set(['bad','worst','boring','hate','terrible','meh','ugly','fail','angry','sad','lose','broken','dislike','😡','💔','👎','😭','trash'])

def tokenize(text):
    text = text.lower()
    text = re.sub(r"[^a-z0-9\s#@_\-]+", " ", text)
    return [t for t in text.split() if t]

def score_tokens(tokens):
    pos = sum(1 for t in tokens if t in POSITIVE)
    neg = sum(1 for t in tokens if t in NEGATIVE)
    score = pos - neg
    label = "positive" if score>0 else ("negative" if score<0 else "neutral")
    return score, label, pos, neg

def main():
    df = pd.read_csv(INPUT)
    df["title_tokens"] = df["title"].fillna("").apply(tokenize)
    df["tags_tokens"] = df["tags"].fillna("").apply(tokenize)
    df["all_tokens"] = (df["title_tokens"] + df["tags_tokens"])
    scored = df.copy()
    scored[["sentiment_score","sentiment_label","pos_hits","neg_hits"]] = scored["all_tokens"].apply(lambda toks: pd.Series(score_tokens(toks)))
    scored.to_csv(OUTPUT, index=False)
    print("Wrote sentiment-scored file:", OUTPUT)

if __name__ == "__main__":
    main()
