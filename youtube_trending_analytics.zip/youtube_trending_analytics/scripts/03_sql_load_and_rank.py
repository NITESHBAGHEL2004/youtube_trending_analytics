import sqlite3, pandas as pd

IN_CSV = "/mnt/data/youtube_trending_analytics/data/outputs/sentiment_scored.csv"
DB_PATH = "/mnt/data/youtube_trending_analytics/data/outputs/youtube_trending.db"
OUT_CAT_RANK = "/mnt/data/youtube_trending_analytics/data/outputs/category_avg_views_by_region.csv"
OUT_TOP_LIKE_RATE = "/mnt/data/youtube_trending_analytics/data/outputs/top_like_rate_by_region.csv"

def main():
    df = pd.read_csv(IN_CSV)
    with sqlite3.connect(DB_PATH) as con:
        df.to_sql("trending", con, if_exists="replace", index=False)
        q1 = """
        SELECT region, category, AVG(views) AS avg_views
        FROM trending
        GROUP BY region, category
        ORDER BY region ASC, avg_views DESC
        """
        cat_rank = pd.read_sql_query(q1, con)
        cat_rank.to_csv(OUT_CAT_RANK, index=False)

        q2 = """
        SELECT region, video_id, title,
               AVG(CASE WHEN views > 0 THEN CAST(likes AS FLOAT)/views END) AS like_rate
        FROM trending
        GROUP BY region, video_id, title
        ORDER BY region ASC, like_rate DESC
        LIMIT 30
        """
        like_rate = pd.read_sql_query(q2, con)
        like_rate.to_csv(OUT_TOP_LIKE_RATE, index=False)

    print("Wrote:", OUT_CAT_RANK, "and", OUT_TOP_LIKE_RATE, "and DB at", DB_PATH)

if __name__ == "__main__":
    main()
