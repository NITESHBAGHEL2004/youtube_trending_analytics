import pandas as pd
import matplotlib.pyplot as plt

IN_CSV = "/mnt/data/youtube_trending_analytics/data/outputs/sentiment_scored.csv"
FIG_DIR = "/mnt/data/youtube_trending_analytics/figures"

def main():
    df = pd.read_csv(IN_CSV)
    df["trending_date"] = pd.to_datetime(df["trending_date"], errors="coerce")

    ts = df.groupby(["region","trending_date"])["views"].sum().reset_index()
    for region in sorted(df["region"].dropna().unique()):
        sub = ts[ts["region"]==region].sort_values("trending_date")
        plt.figure()
        plt.plot(sub["trending_date"], sub["views"])
        plt.title(f"Daily Total Views (Trending) - {region}")
        plt.xlabel("Date")
        plt.ylabel("Total Views")
        plt.tight_layout()
        out = f"{FIG_DIR}/time_series_views_{region}.png"
        plt.savefig(out, dpi=140)
        plt.close()

    dur = df.drop_duplicates(subset=["video_id","region"])[["category","trending_days"]]
    by_cat = dur.groupby("category")["trending_days"].mean().sort_values(ascending=False)
    plt.figure()
    by_cat.plot(kind="bar")
    plt.title("Average Trending Duration by Category")
    plt.xlabel("Category")
    plt.ylabel("Avg Trending Days")
    plt.tight_layout()
    out = f"{FIG_DIR}/avg_trending_duration_by_category.png"
    plt.savefig(out, dpi=140)
    plt.close()

    mix = df.drop_duplicates(subset=["video_id","region"]).groupby(["region","sentiment_label"]).size().unstack(fill_value=0)
    if set(["negative","neutral","positive"]).issubset(mix.columns):
        mix = mix[["negative","neutral","positive"]]
    mix_ratio = mix.div(mix.sum(axis=1), axis=0)
    plt.figure()
    bottom = None
    for col in mix_ratio.columns:
        if bottom is None:
            plt.bar(mix_ratio.index, mix_ratio[col])
            bottom = mix_ratio[col].values
        else:
            plt.bar(mix_ratio.index, mix_ratio[col], bottom=bottom)
            bottom = bottom + mix_ratio[col].values
    plt.title("Sentiment Distribution by Region")
    plt.xlabel("Region")
    plt.ylabel("Share")
    plt.tight_layout()
    out = f"{FIG_DIR}/sentiment_distribution_by_region.png"
    plt.savefig(out, dpi=140)
    plt.close()

    print("Wrote figures to:", FIG_DIR)

if __name__ == "__main__":
    main()
